# Exercise 04.02: Inspect the project implementation of time-domain and frequency features

**Exercise ID:** `exercise-04-02`  
**Objective:** Demonstrate understanding of A classifier can summarize a sequence with statistics and frequency components before making a prediction. with source evidence.  
**Difficulty:** Intermediate  
**Estimated time:** 45 minutes

## Problem

Trace one real input through the time-domain and frequency features portion of `src/model.py`. Explain what the source does, distinguish verified behavior from any proposed feature, and identify an edge case.

## Requirements
- Cite at least two relevant source lines or symbols.
- Record input, transformation, output, and failure behavior.
- Build one small test, hand-worked example, or diagnostic appropriate to the project.
- State whether the result is implemented, configured, or only described.

## Constraints
Do not use real personal/biometric/financial data or expose secrets. Do not claim execution unless you performed it.

## Expected behavior and acceptance criteria
- The explanation matches the cited source.
- The example has a stated expected result and meaningful edge case.
- A limitation and human review requirement are documented.

## Hints
Start at the documented entry point; follow one function call at a time; inspect tests and setup docs before assuming an artifact exists.
