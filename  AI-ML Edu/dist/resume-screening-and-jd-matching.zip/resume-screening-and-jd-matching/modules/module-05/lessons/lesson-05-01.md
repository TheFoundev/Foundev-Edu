# Flask UI and Model Runtime: Understand app route, batch processing, and spaCy/model dependencies

**Lesson ID:** `lesson-05-01`  
**Module:** Flask UI and Model Runtime  
**Source focus:** `app.py` → `load_models`

## Purpose and learning objectives

This lesson begins with an everyday explanation and then follows the implementation used by TalentMatch Lens: Resume and Job Description Matching. By the end, you can describe app route, batch processing, and spaCy/model dependencies, trace the flask ui and model runtime implementation to source code, and identify one way it can fail.

## Prerequisites

Basic Python and the project setup guide. For later lessons, first complete the preceding lesson in this module.

## The idea in plain language

In everyday language, this module is about app route, batch processing, and spaCy/model dependencies. First understand what information enters this stage, what it changes, and what it sends onward.

## What this project actually implements

The source-specific focus for this module is `load_models` in `app.py`. Use the excerpt below to trace the actual inputs, transformation, and output for app route, batch processing, and spaCy/model dependencies. Where a behavior is absent, follow the documented boundary rather than assuming it exists.

This is a source-grounded description, not a claim that code was run. The repository-specific limitation to keep visible is: The embedding model is used zero-shot and no evaluation/training data is supplied. Similarity can encode proxy bias and must not rank or reject applicants without meaningful human review.

## Step-by-step source investigation

1. Open `app.py` and inspect `load_models`.
2. Read its inputs and output, then follow its caller and the next step in the data flow.
3. Record the data representation at each boundary (text, image, table, vector, score, or response).
4. Inspect validation, fallback, and exception behavior.
5. Compare the behavior with `PROJECT_OVERVIEW.md` and `WORKFLOW.md`; report any contradiction instead of silently choosing a claim.

## Code-reading example

Source excerpt from `app.py` (not executed during package generation):

```python
def load_models():
    """Loads the spaCy NLP pipeline, skill matcher, and embedding model."""
    nlp = spacy.load("en_core_web_sm")
    skill_matcher = load_skill_matcher(nlp)
    embedder = ResumeEmbedder(model_name="all-MiniLM-L6-v2")
    return nlp, skill_matcher, embedder
```

Read the arguments first, trace the transformation and conditions, then locate the returned value or side effect. This source excerpt was not executed during package generation.

## Expected behavior

A correct investigation yields a traceable input → processing → result path, a source citation, and one explicit caveat. For flask ui and model runtime, use the repository's own output format and the available test fixture where possible.

## Practical exercise

Complete [`exercise-05-01.md`](../exercises/exercise-05-01.md).

## Common mistakes and debugging

- Confusing a visual mockup or demo heuristic with the model/pipeline implementation.
- Assuming an absent data file, weight, service, or credential is bundled.
- Reporting accuracy without checking class balance, split strategy, or an appropriate baseline.
- Editing a pipeline before establishing input shape and output contract.
- Treating confidence/similarity as calibrated probability or proof.

## Best practices and responsible use

Keep data provenance and split boundaries explicit, make errors visible, log no sensitive raw inputs unnecessarily, and retain a human correction path for consequential outputs. Test failure and missing-artifact cases as well as the happy path.

## Summary

You can now understand app route, batch processing, and spacy/model dependencies, identify its source location, and state a limitation. The key project-specific fact is: Understand app route, batch processing, and spaCy/model dependencies. In this repository, the claim must be grounded in the documented behavior and source paths: app.py; index.html; WORKFLOW.md.

## Knowledge check

1. What input enters this stage, and what output leaves it?
2. Which source path proves the behavior?
3. What assumption would make the output unreliable?

## References

- The matching source repository files `PROJECT_OVERVIEW.md` and `WORKFLOW.md` (paths relative to that repository).
- [Python documentation](https://docs.python.org/3/)
- [NIST AI Risk Management Framework](https://www.nist.gov/itl/ai-risk-management-framework)
