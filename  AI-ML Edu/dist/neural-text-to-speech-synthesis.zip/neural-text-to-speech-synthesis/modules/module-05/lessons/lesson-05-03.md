# Formants, Duration, and Prosody: Validate outputs and identify limitations for formants, duration, and prosody

**Lesson ID:** `lesson-05-03`  
**Module:** Formants, Duration, and Prosody  
**Source focus:** `src/model.py` → `_render_phrase`

## Purpose and learning objectives

This lesson begins with an everyday explanation and then follows the implementation used by Neural Text-to-Speech Synthesis. By the end, you can describe Vowels contribute resonant frequencies, consonants contribute noise or bursts, and duration/pitch shape the phrase., trace the formants, duration, and prosody implementation to source code, and identify one way it can fail.

## Prerequisites

Basic Python and the project setup guide. For later lessons, first complete the preceding lesson in this module.

## The idea in plain language

In everyday language, this module is about Vowels contribute resonant frequencies, consonants contribute noise or bursts, and duration/pitch shape the phrase.. First understand what information enters this stage, what it changes, and what it sends onward.

## What this project actually implements

The source-specific focus for this module is `_render_phrase` in `src/model.py`. Use the excerpt below to trace the actual inputs, transformation, and output for Vowels contribute resonant frequencies, consonants contribute noise or bursts, and duration/pitch shape the phrase.. Where a behavior is absent, follow the documented boundary rather than assuming it exists.

This is a source-grounded description, not a claim that code was run. The repository-specific limitation to keep visible is: **This is not a neural TTS.** There is no acoustic model, no attention, no vocoder and no learned pronunciation; the project implements the classical pipeline that such a system would replace. A real Tacotron2 + WaveGlow build needs a GPU, a training corpus of hours and a dependency on TensorFlow, none of which fit in this environment.

## Step-by-step source investigation

1. Open `src/model.py` and inspect `_render_phrase`.
2. Read its inputs and output, then follow its caller and the next step in the data flow.
3. Record the data representation at each boundary (text, image, table, vector, score, or response).
4. Inspect validation, fallback, and exception behavior.
5. Compare the behavior with the source `README.md` and nearby implementation; report any contradiction instead of silently choosing a claim.

## Code-reading example

Source excerpt from `src/model.py` (not executed during package generation):

```python
def _render_phrase(
    phrase: str,
    sample_rate: int,
    duration: float | None,
    duration_model: DurationModel | None,
    prosody: Prosody | None,
    seed: int,
) -> tuple[np.ndarray, list[tuple[str, int, int]]]:
    """Render a phrase and report where every phoneme is."""
    prosody = (prosody or Prosody()).with_text(phrase)
    words = phonemize(phrase)
    if not words:
        return np.zeros(0, dtype=np.int16), []

    model = duration_model
    if model is None:
        model = fit_duration_model([("x", 5, 2, 0.6)])

    word_durations = []
    for word in words:
```

Read the arguments first, trace the transformation and conditions, then locate the returned value or side effect. This source excerpt was not executed during package generation.

## Expected behavior

A correct investigation yields a traceable input → processing → result path, a source citation, and one explicit caveat. For formants, duration, and prosody, use the repository's own output format and the available test fixture where possible.

## Practical exercise

Complete [`exercise-05-03.md`](../exercises/exercise-05-03.md).

## Common mistakes and debugging

- Confusing a visual mockup or demo heuristic with the model/pipeline implementation.
- Assuming an absent data file, weight, service, or credential is bundled.
- Reporting accuracy without checking class balance, split strategy, or an appropriate baseline.
- Editing a pipeline before establishing input shape and output contract.
- Treating confidence/similarity as calibrated probability or proof.

## Best practices and responsible use

Keep data provenance and split boundaries explicit, make errors visible, log no sensitive raw inputs unnecessarily, and retain a human correction path for consequential outputs. Test failure and missing-artifact cases as well as the happy path.

## Summary

You can now validate outputs and identify limitations for formants, duration, and prosody, identify its source location, and state a limitation. The key project-specific fact is: Validate outputs and identify limitations for formants, duration, and prosody. In this repository, the claim must be grounded in the documented behavior and source paths: src/model.py.

## Knowledge check

1. What input enters this stage, and what output leaves it?
2. Which source path proves the behavior?
3. What assumption would make the output unreliable?

## References

- The matching source repository `README.md` and cited code files (paths relative to that repository).
- [Python documentation](https://docs.python.org/3/)
- [NIST AI Risk Management Framework](https://www.nist.gov/itl/ai-risk-management-framework)
