# Assess failure and operational limits of test fixtures and security tests

**Lesson ID:** lesson-03  
**Module ID:** module-11  
**Estimated duration:** 30 minutes

## Purpose and learning objectives

This lesson introduces **Test Fixtures and Security Tests** in Audited Escrow and Tokenization Contracts. Begin with the plain-language model, then trace the source implementation and examine its operational boundary.

## Prerequisites

Read the earlier lesson in this module. The project uses Solidity 0.8.24, Hardhat, TypeScript, ethers.js, OpenZeppelin Contracts. Use a local, simulation, or test environment described in setup-guide.md.

## Topic in plain language

A test attacker calls back during a transfer to test whether a withdrawal can be repeated.

## Move from the idea to the source

Move from the happy path to operational reasoning. For this project, Hardhat tests cover state transitions, timeouts, ERC20, reentrancy, token roles/pausing/royalties, and factory indexing.

The distinction to keep in view is what the supplied files implement versus what a larger production system would require. The README lists known limitations and source discrepancies.

## Step-by-step

1. Identify a failure, boundary, or unexpected input.
2. Use `test/escrow.spec.ts` and the `reentrancy` path to predict behavior: Hardhat tests cover state transitions, timeouts, ERC20, reentrancy, token roles/pausing/royalties, and factory indexing.
3. Describe a safe local/test verification and what evidence to collect.
4. State what additional code or infrastructure would be needed before making a production claim.

## Source-code walkthrough

**Source file(s):** contracts/test/ReentrancyAttacker.sol; test/escrow.spec.ts

**Source:** `test/escrow.spec.ts:368–377`  
**Focus cue:** `reentrancy`

````ts
await expect(escrow.connect(buyer).fundERC20(1n)).to.be.reverted;
  });
});

describe("Escrow (reentrancy)", () => {
  it("blocks a re-entrant withdraw from the seller's receive hook", async () => {
    const { escrow, attacker, buyer, amount } = await loadFixture(reentrancyFixture);
    const attackerAddress = await attacker.getAddress();
````

Read the excerpt in context. Follow the focus cue to its caller or consumer, then state the behavior and one boundary. This copied source excerpt was not executed during content generation. For cryptography, secrets, infrastructure, and smart-contract topics, use official references and treat the package as educational material, not security approval.

## Expected behavior

The code-level finding is: Hardhat tests cover state transitions, timeouts, ERC20, reentrancy, token roles/pausing/royalties, and factory indexing. The original application was not modified or deployed by this content package.

## Practical exercise

Trace one input through the named source. Record the input, validation, state/data change, result, and one failure path. Then design a safe verification plan with the expected result and evidence.

## Common mistakes and debugging

- Treating a README feature list as proof of a real integration.
- Assuming an interface-shaped model is compatible with a provider protocol.
- Confusing passing unit tests with a production guarantee or independent security audit.
- Running destructive host, cluster, contract, or cloud operations against real resources.
- Logging secrets or relying on hard-coded sample credentials.

## Best practices and security

Use disposable environments, least privilege, explicit credential handling, and bounded inputs. For contracts, secrets, infrastructure, and host command runners, inspect the target before execution and separate test from production resources.

## Summary

You moved from a beginner explanation to the actual source behavior and its operational limits. You can cite the file and explain one verification path.

## Knowledge check

1. Which file/function implements the behavior?
2. What data or state changes?
3. What does the source not prove or provide?

## References

Use the official links in references.json.
