# Assess failure and operational limits of deploy and audit limits

**Lesson ID:** lesson-03  
**Module ID:** module-12  
**Estimated duration:** 30 minutes

## Purpose and learning objectives

This lesson introduces **Deploy and Audit Limits** in Audited Escrow and Tokenization Contracts. Begin with the plain-language model, then trace the source implementation and examine its operational boundary.

## Prerequisites

Read the earlier lesson in this module. The project uses Solidity 0.8.24, Hardhat, TypeScript, ethers.js, OpenZeppelin Contracts. Use a local, simulation, or test environment described in setup-guide.md.

## Topic in plain language

A deploy script connects code to a chain; a test report is evidence for tested cases, not a security certification.

## Move from the idea to the source

Move from the happy path to operational reasoning. For this project, README reports local compile/tests, uses a zero-filled placeholder PRIVATE_KEY, and supplies no independent audit report.

The distinction to keep in view is what the supplied files implement versus what a larger production system would require. The README lists known limitations and source discrepancies.

## Step-by-step

1. Identify a failure, boundary, or unexpected input.
2. Use `hardhat.config.ts` and the `PRIVATE_KEY` path to predict behavior: README reports local compile/tests, uses a zero-filled placeholder PRIVATE_KEY, and supplies no independent audit report.
3. Describe a safe local/test verification and what evidence to collect.
4. State what additional code or infrastructure would be needed before making a production claim.

## Source-code walkthrough

**Source file(s):** scripts/deploy.ts; hardhat.config.ts; README.md

**Source:** `hardhat.config.ts:8–17`  
**Focus cue:** `PRIVATE_KEY`

````ts
* PRIVATE_KEY must NEVER be a real key in a committed file — export it in
 * your shell (or source an untracked .env) before running a live deploy.
 */
const localhostUrl = process.env.LOCALHOST_RPC_URL ?? "http://127.0.0.1:8545";
const sepoliaUrl = process.env.SEPOLIA_RPC_URL;
const accounts = process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : [];

const config: HardhatUserConfig = {
  solidity: {
    version: "0.8.24",
````

Read the excerpt in context. Follow the focus cue to its caller or consumer, then state the behavior and one boundary. This copied source excerpt was not executed during content generation. For cryptography, secrets, infrastructure, and smart-contract topics, use official references and treat the package as educational material, not security approval.

## Expected behavior

The code-level finding is: README reports local compile/tests, uses a zero-filled placeholder PRIVATE_KEY, and supplies no independent audit report. The original application was not modified or deployed by this content package.

## Practical exercise

Trace one input through the named source. Record the input, validation, state/data change, result, and one failure path. Then design a safe verification plan with the expected result and evidence.

## Common mistakes and debugging

- Treating a README feature list as proof of a real integration.
- Assuming an interface-shaped model is compatible with a provider protocol.
- Confusing passing unit tests with a production guarantee or independent security audit.
- Running destructive host, cluster, contract, or cloud operations against real resources.
- Logging secrets or relying on hard-coded sample credentials.

## Best practices and security

Use disposable environments, least privilege, explicit credential handling, and bounded inputs. For contracts, secrets, infrastructure, and host command runners, inspect the target before execution and separate test from production resources.

## Summary

You moved from a beginner explanation to the actual source behavior and its operational limits. You can cite the file and explain one verification path.

## Knowledge check

1. Which file/function implements the behavior?
2. What data or state changes?
3. What does the source not prove or provide?

## References

Use the official links in references.json.
