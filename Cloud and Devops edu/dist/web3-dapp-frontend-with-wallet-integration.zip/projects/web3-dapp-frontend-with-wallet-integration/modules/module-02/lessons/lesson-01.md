# Explain validate address shape and checksum using a plain-language model

**Lesson ID:** lesson-01  
**Module ID:** module-02  
**Estimated duration:** 30 minutes

## Purpose and learning objectives

This lesson introduces **Validate Address Shape and Checksum** in Web3 dApp Frontend with Wallet Integration. Begin with the plain-language model, then trace the source implementation and examine its operational boundary.

## Prerequisites

Read the earlier lesson in this module. The project uses Node.js, JavaScript, Ethereum JSON-RPC, EIP-1193 provider, Keccak-256. Use a local, simulation, or test environment described in setup-guide.md.

## Topic in plain language

A 20-byte hex address shape is different from EIP-55 mixed-case checksum validation.

## Move from the idea to the source

Begin with this mental model: A 20-byte hex address shape is different from EIP-55 mixed-case checksum validation. Identify the actual components in src/ethereum.js; src/keccak.js.

The distinction to keep in view is what the supplied files implement versus what a larger production system would require. The README lists known limitations and source discrepancies.

## Step-by-step

1. State the idea in your own words before reading code.
2. Open `src/ethereum.js` at the cited lines and identify the input and output.
3. Compare the analogy with the implementation: isAddress checks 40 hex characters; hasValidChecksum computes Keccak casing; README notes checksum validation limits in UI.
4. Write one question the analogy does not answer about real deployments.

## Source-code walkthrough

**Source file(s):** src/ethereum.js; src/keccak.js

**Source:** `src/ethereum.js:72–81`  
**Focus cue:** `hasValidChecksum`

````js
return `0x${TRANSFER_SELECTOR}${address}${encodedValue}`;
}

module.exports = {
  isAddress,
  hasValidChecksum,
  normalizeAddress,
  formatUnits,
  parseUnits,
  encodeTransfer,
````

Read the excerpt in context. Follow the focus cue to its caller or consumer, then state the behavior and one boundary. This copied source excerpt was not executed during content generation. For cryptography, secrets, infrastructure, and smart-contract topics, use official references and treat the package as educational material, not security approval.

## Expected behavior

The code-level finding is: isAddress checks 40 hex characters; hasValidChecksum computes Keccak casing; README notes checksum validation limits in UI. The original application was not modified or deployed by this content package.

## Practical exercise

Trace one input through the named source. Record the input, validation, state/data change, result, and one failure path. Then design a safe verification plan with the expected result and evidence.

## Common mistakes and debugging

- Treating a README feature list as proof of a real integration.
- Assuming an interface-shaped model is compatible with a provider protocol.
- Confusing passing unit tests with a production guarantee or independent security audit.
- Running destructive host, cluster, contract, or cloud operations against real resources.
- Logging secrets or relying on hard-coded sample credentials.

## Best practices and security

Use disposable environments, least privilege, explicit credential handling, and bounded inputs. For contracts, secrets, infrastructure, and host command runners, inspect the target before execution and separate test from production resources.

## Summary

You moved from a beginner explanation to the actual source behavior and its operational limits. You can cite the file and explain one verification path.

## Knowledge check

1. Which file/function implements the behavior?
2. What data or state changes?
3. What does the source not prove or provide?

## References

Use the official links in references.json.
