# Testing and Reconciliation: Validate outputs and identify limitations for testing and reconciliation

**Lesson ID:** `lesson-05-03`  
**Module:** Testing and Reconciliation  
**Source focus:** `WORKFLOW.md` → `read_sql`

## Purpose and learning objectives

This lesson begins with an everyday explanation and then follows the implementation used by DemandSight: Retail Sales Analytics. By the end, you can describe totals, signed profit, nulls, and missing pymysql dependency, trace the testing and reconciliation implementation to source code, and identify one way it can fail.

## Prerequisites

Basic Python and the project setup guide. For later lessons, first complete the preceding lesson in this module.

## The idea in plain language

In everyday language, this module is about totals, signed profit, nulls, and missing pymysql dependency. First understand what information enters this stage, what it changes, and what it sends onward.

## What this project actually implements

The source-specific focus for this module is `read_sql` in `run_all_queries.py`. Use the excerpt below to trace the actual inputs, transformation, and output for totals, signed profit, nulls, and missing pymysql dependency. Where a behavior is absent, follow the documented boundary rather than assuming it exists.

This is a source-grounded description, not a claim that code was run. The repository-specific limitation to keep visible is: No forecasting model exists: the implementation aggregates transaction data. The ETL requires MySQL and pymysql is omitted from requirements. Seasonal prediction is an extension, not shipped behavior.

## Step-by-step source investigation

1. Open `run_all_queries.py` and inspect `read_sql`.
2. Read its inputs and output, then follow its caller and the next step in the data flow.
3. Record the data representation at each boundary (text, image, table, vector, score, or response).
4. Inspect validation, fallback, and exception behavior.
5. Compare the behavior with `PROJECT_OVERVIEW.md` and `WORKFLOW.md`; report any contradiction instead of silently choosing a claim.

## Code-reading example

Source excerpt from `run_all_queries.py` (not executed during package generation):

```python
# Execute each query and display result
for i, query in enumerate(queries, start=1):
    print(f"\n📌 Query {i}:\n{query}\n")
    try:
        df = pd.read_sql(query, con=engine)
        print(df.head(10))
    except Exception as e:
        print(f"❌ Error running Query {i}: {e}")
```

Read the arguments first, trace the transformation and conditions, then locate the returned value or side effect. This source excerpt was not executed during package generation.

## Expected behavior

A correct investigation yields a traceable input → processing → result path, a source citation, and one explicit caveat. For testing and reconciliation, use the repository's own output format and the available test fixture where possible.

## Practical exercise

Complete [`exercise-05-03.md`](../exercises/exercise-05-03.md).

## Common mistakes and debugging

- Confusing a visual mockup or demo heuristic with the model/pipeline implementation.
- Assuming an absent data file, weight, service, or credential is bundled.
- Reporting accuracy without checking class balance, split strategy, or an appropriate baseline.
- Editing a pipeline before establishing input shape and output contract.
- Treating confidence/similarity as calibrated probability or proof.

## Best practices and responsible use

Keep data provenance and split boundaries explicit, make errors visible, log no sensitive raw inputs unnecessarily, and retain a human correction path for consequential outputs. Test failure and missing-artifact cases as well as the happy path.

## Summary

You can now validate outputs and identify limitations for testing and reconciliation, identify its source location, and state a limitation. The key project-specific fact is: Validate outputs and identify limitations for testing and reconciliation. In this repository, the claim must be grounded in the documented behavior and source paths: WORKFLOW.md; requirements.txt; run_all_queries.py.

## Knowledge check

1. What input enters this stage, and what output leaves it?
2. Which source path proves the behavior?
3. What assumption would make the output unreliable?

## References

- The matching source repository files `PROJECT_OVERVIEW.md` and `WORKFLOW.md` (paths relative to that repository).
- [Python documentation](https://docs.python.org/3/)
- [NIST AI Risk Management Framework](https://www.nist.gov/itl/ai-risk-management-framework)
