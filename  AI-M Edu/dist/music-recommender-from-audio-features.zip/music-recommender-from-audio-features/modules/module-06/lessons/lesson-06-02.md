# Evaluation, Bias, and Product Limits: Inspect the project implementation of evaluation, bias, and product limits

**Lesson ID:** `lesson-06-02`  
**Module:** Evaluation, Bias, and Product Limits  
**Source focus:** `src/api.py` → `recommend`

## Purpose and learning objectives

This lesson begins with an everyday explanation and then follows the implementation used by Groove Observatory: Audio Feature Music Recommendation. By the end, you can describe catalogue bias, cold start, diversity, and user control, trace the evaluation, bias, and product limits implementation to source code, and identify one way it can fail.

## Prerequisites

Basic Python and the project setup guide. For later lessons, first complete the preceding lesson in this module.

## The idea in plain language

In everyday language, this module is about catalogue bias, cold start, diversity, and user control. First understand what information enters this stage, what it changes, and what it sends onward.

## What this project actually implements

The source-specific focus for this module is `recommend` in `src/api.py`. Use the excerpt below to trace the actual inputs, transformation, and output for catalogue bias, cold start, diversity, and user control. Where a behavior is absent, follow the documented boundary rather than assuming it exists.

This is a source-grounded description, not a claim that code was run. The repository-specific limitation to keep visible is: This is deterministic cosine-neighbor ranking over a local 2,261-row, ten-feature catalogue, not a learned recommender. Catalog coverage and popularity bias limit results.

## Step-by-step source investigation

1. Open `src/api.py` and inspect `recommend`.
2. Read its inputs and output, then follow its caller and the next step in the data flow.
3. Record the data representation at each boundary (text, image, table, vector, score, or response).
4. Inspect validation, fallback, and exception behavior.
5. Compare the behavior with `PROJECT_OVERVIEW.md` and `WORKFLOW.md`; report any contradiction instead of silently choosing a claim.

## Code-reading example

Source excerpt from `src/api.py` (not executed during package generation):

```python
def recommend():
    payload = request.get_json(silent=True) or {}
    artist = payload.get("artist")
    title = payload.get("title")
    if not artist or not title:
        return jsonify({"error": "'artist' and 'title' are required"}), 400
    limit = int(payload.get("limit", 10))
    limit = max(1, min(limit, 50))
    exclude_self = bool(payload.get("excludeSelf", True))

    seed = find_seed(str(artist), str(title))
    if seed is None:
        return jsonify({"error": "Song not found for that artist"}), 404

    seed_idx = DATA.index.get_loc(seed.name)
    sims = cosine_similarity(MATRIX[seed_idx:seed_idx + 1], MATRIX)[0]
    order = sims.argsort()[::-1]

    recommendations = []
    for idx in order:
```

Read the arguments first, trace the transformation and conditions, then locate the returned value or side effect. This source excerpt was not executed during package generation.

## Expected behavior

A correct investigation yields a traceable input → processing → result path, a source citation, and one explicit caveat. For evaluation, bias, and product limits, use the repository's own output format and the available test fixture where possible.

## Practical exercise

Complete [`exercise-06-02.md`](../exercises/exercise-06-02.md).

## Common mistakes and debugging

- Confusing a visual mockup or demo heuristic with the model/pipeline implementation.
- Assuming an absent data file, weight, service, or credential is bundled.
- Reporting accuracy without checking class balance, split strategy, or an appropriate baseline.
- Editing a pipeline before establishing input shape and output contract.
- Treating confidence/similarity as calibrated probability or proof.

## Best practices and responsible use

Keep data provenance and split boundaries explicit, make errors visible, log no sensitive raw inputs unnecessarily, and retain a human correction path for consequential outputs. Test failure and missing-artifact cases as well as the happy path.

## Summary

You can now inspect the project implementation of evaluation, bias, and product limits, identify its source location, and state a limitation. The key project-specific fact is: The source-specific focus for this module is `recommend` in `src/api.py`. Use the excerpt below to trace the actual inputs, transformation, and output for catalogue bias, cold start, diversity, and user control. Where a behavior is absent, follow the documented boundary rather than assuming it exists.

## Knowledge check

1. What input enters this stage, and what output leaves it?
2. Which source path proves the behavior?
3. What assumption would make the output unreliable?

## References

- The matching source repository files `PROJECT_OVERVIEW.md` and `WORKFLOW.md` (paths relative to that repository).
- [Python documentation](https://docs.python.org/3/)
- [NIST AI Risk Management Framework](https://www.nist.gov/itl/ai-risk-management-framework)
