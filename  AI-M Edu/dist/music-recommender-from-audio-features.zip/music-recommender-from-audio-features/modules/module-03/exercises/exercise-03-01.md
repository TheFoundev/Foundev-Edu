# Exercise 03.01: Understand vector geometry and neighborhood results

**Exercise ID:** `exercise-03-01`  
**Objective:** Demonstrate understanding of vector geometry and neighborhood results with source evidence.  
**Difficulty:** Intermediate  
**Estimated time:** 35 minutes

## Problem

Trace one real input through the cosine similarity and ranking portion of `src/main_cosine_similarity.py`. Explain what the source does, distinguish verified behavior from any proposed feature, and identify an edge case.

## Requirements
- Cite at least two relevant source lines or symbols.
- Record input, transformation, output, and failure behavior.
- Build one small test, hand-worked example, or diagnostic appropriate to the project.
- State whether the result is implemented, configured, or only described.

## Constraints
Do not use real personal/biometric/financial data or expose secrets. Do not claim execution unless you performed it.

## Expected behavior and acceptance criteria
- The explanation matches the cited source.
- The example has a stated expected result and meaningful edge case.
- A limitation and human review requirement are documented.

## Hints
Start at the documented entry point; follow one function call at a time; inspect tests and setup docs before assuming an artifact exists.
