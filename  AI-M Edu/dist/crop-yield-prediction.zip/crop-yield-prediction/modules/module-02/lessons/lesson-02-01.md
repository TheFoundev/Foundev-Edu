# Earth Engine and MODIS Data: Understand export, nine bands, and raster organization

**Lesson ID:** `lesson-02-01`  
**Module:** Earth Engine and MODIS Data  
**Source focus:** `cyp/data/exporting.py` → `export`

## Purpose and learning objectives

This lesson begins with an everyday explanation and then follows the implementation used by YieldSight: County-Level Crop Yield Prediction. By the end, you can describe export, nine bands, and raster organization, trace the earth engine and modis data implementation to source code, and identify one way it can fail.

## Prerequisites

Basic Python and the project setup guide. For later lessons, first complete the preceding lesson in this module.

## The idea in plain language

In everyday language, this module is about export, nine bands, and raster organization. First understand what information enters this stage, what it changes, and what it sends onward.

## What this project actually implements

### The nine MODIS bands

The exporter builds each county-year's stack from three MODIS products (`data/README.md`):

| Product | Role | Contribution |
|---|---|---|
| **MOD09A1** surface reflectance | red, NIR, blue reflectance at 1 km, 8-day | 7 of the 9 bands |
| **MYD11A2** land-surface temperature | day/night temperature at 1 km, 8-day | 2 of the 9 bands |
| **MCD12Q1** land cover | the IGBP classification | not a band — used as the **farmland mask** |

After the reflectance bands are shifted into the 0–10 000 space that the temperature bands occupy, the network's `in_channels` is **9** (7 reflectance + 2 temperature).

Connect this explanation to `cyp/data/exporting.py` and the source focus `export`.

This is a source-grounded description, not a claim that code was run. The repository-specific limitation to keep visible is: The workflow needs Earth Engine exports and large raster data not included in the package. Optional error-map dependencies are missing from the declared environment; results require spatially honest evaluation.

## Step-by-step source investigation

1. Open `cyp/data/exporting.py` and inspect `export`.
2. Read its inputs and output, then follow its caller and the next step in the data flow.
3. Record the data representation at each boundary (text, image, table, vector, score, or response).
4. Inspect validation, fallback, and exception behavior.
5. Compare the behavior with `PROJECT_OVERVIEW.md` and `WORKFLOW.md`; report any contradiction instead of silently choosing a claim.

## Code-reading example

Source excerpt from `cyp/data/exporting.py` (not executed during package generation):

```python
def export(
        self,
        folder_name,
        data_type,
        coordinate_system="EPSG:4326",
        scale=500,
        export_limit=None,
        min_img_val=None,
        max_img_val=None,
        major_states_only=True,
        check_if_done=False,
        download_folder=None,
    ):
        """Export an Image Collection from Earth Engine to Google Drive

        Parameters
        ----------
            folder_name: str
                The name of the folder to export the images to in
                Google Drive. If the folder is not there, this process
```

Read the arguments first, trace the transformation and conditions, then locate the returned value or side effect. This source excerpt was not executed during package generation.

## Expected behavior

A correct investigation yields a traceable input → processing → result path, a source citation, and one explicit caveat. For earth engine and modis data, use the repository's own output format and the available test fixture where possible.

## Practical exercise

Complete [`exercise-02-01.md`](../exercises/exercise-02-01.md).

## Common mistakes and debugging

- Confusing a visual mockup or demo heuristic with the model/pipeline implementation.
- Assuming an absent data file, weight, service, or credential is bundled.
- Reporting accuracy without checking class balance, split strategy, or an appropriate baseline.
- Editing a pipeline before establishing input shape and output contract.
- Treating confidence/similarity as calibrated probability or proof.

## Best practices and responsible use

Keep data provenance and split boundaries explicit, make errors visible, log no sensitive raw inputs unnecessarily, and retain a human correction path for consequential outputs. Test failure and missing-artifact cases as well as the happy path.

## Summary

You can now understand export, nine bands, and raster organization, identify its source location, and state a limitation. The key project-specific fact is: Understand export, nine bands, and raster organization. In this repository, the claim must be grounded in the documented behavior and source paths: cyp/data/exporting.py; data/README.md.

## Knowledge check

1. What input enters this stage, and what output leaves it?
2. Which source path proves the behavior?
3. What assumption would make the output unreliable?

## References

- The matching source repository files `PROJECT_OVERVIEW.md` and `WORKFLOW.md` (paths relative to that repository).
- [Python documentation](https://docs.python.org/3/)
- [NIST AI Risk Management Framework](https://www.nist.gov/itl/ai-risk-management-framework)
