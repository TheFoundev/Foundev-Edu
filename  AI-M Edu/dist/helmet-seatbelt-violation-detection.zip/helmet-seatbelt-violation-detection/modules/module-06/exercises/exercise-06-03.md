# Exercise 06.03: Validate outputs and identify limitations for safety, privacy, and human review

**Exercise ID:** `exercise-06-03`  
**Objective:** Demonstrate understanding of surveillance limits, false positives, and enforcement safeguards with source evidence.  
**Difficulty:** Advanced  
**Estimated time:** 55 minutes

## Problem

Trace one real input through the safety, privacy, and human review portion of `source/main_app.py`. Explain what the source does, distinguish verified behavior from any proposed feature, and identify an edge case.

## Requirements
- Cite at least two relevant source lines or symbols.
- Record input, transformation, output, and failure behavior.
- Build one small test, hand-worked example, or diagnostic appropriate to the project.
- State whether the result is implemented, configured, or only described.

## Constraints
Do not use real personal/biometric/financial data or expose secrets. Do not claim execution unless you performed it.

## Expected behavior and acceptance criteria
- The explanation matches the cited source.
- The example has a stated expected result and meaningful edge case.
- A limitation and human review requirement are documented.

## Hints
Start at the documented entry point; follow one function call at a time; inspect tests and setup docs before assuming an artifact exists.
