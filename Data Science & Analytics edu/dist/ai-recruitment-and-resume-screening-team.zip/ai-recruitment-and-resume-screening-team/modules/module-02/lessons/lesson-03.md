# Model and Data: Test the boundary

**Lesson ID:** `ai-recruitment-and-resume-screening-team-module-02-lesson-03`  
**Module ID:** `ai-recruitment-and-resume-screening-team-module-02`  
**Source focus:** `src/model.py` → `resume_features`

## Purpose and learning objectives

Use a test or boundary case to assess what the implementation proves and what remains unverified.

## Prerequisites

Complete the earlier lesson in this module first. This module covers: Model and Data.

## Beginner explanation

In plain language, model and data is one stage in turning source data into a result. This is a mental model, not a claim that every named source component uses a production-grade implementation.

## Step-by-step source reading

1. Open `src/model.py` and locate `resume_features`.
2. Identify its input and returned, stored, displayed, or emitted output.
3. Follow one caller/test into a related source path: `src/model.py`, `src/data.py`.
4. Compare that path with the source README, test fixtures, and documented limitations.

## Source evidence

The selected source finding is: source declarations; imports and callers; inputs and outputs

**Excerpt:** `src/model.py` at lines 34–54. Source code was not executed during refinement.

### src/model.py

The excerpt below is the selected implementation focus.
### src/data.py

This mapped path is part of the module scope; inspect it alongside its callers and tests.

```py
}


def resume_features(resume):
    """The features of a resume.

    The facts come from the text of the resume, so the parser is used and not
    the fields the generator filled in.
    """
    parsed = parse_resume(resume["text"])
    text = resume["text"].lower()
    found = [skill for skill in SKILLS if skill in text]

    return {
        "text": resume["text"],
        "years": parsed["years"],
        "projects": parsed["projects"],
        "education": parsed["education"],
        "skills": found,
    }
```

Use the test or boundary to separate checked behavior from real-world performance, deployment, or provider claims.

## Expected behavior and limits

source declarations; imports and callers; inputs and outputs The repository’s README notes and tests are part of the scope; no application execution is claimed by this package.

## Practical exercise

Complete [`exercise-02.md`](../exercises/exercise-02.md). Cite the focus symbol and source path, record an expected result, and describe one edge case.

## Common mistakes and debugging

- Confusing the repository’s title or project brief with the implementation that is present.
- Treating a test definition as evidence that the test passed.
- Ignoring sample-data, small-dataset, synthetic-input, or runtime limitations.
- Follow the focus symbol through its caller before drawing conclusions.

## Best practices and security

Use non-sensitive test data, protect credentials, document split and metric assumptions, and do not present synthetic results as production performance. For hiring, public policy, finance, health, or personal data, require qualified human review.

## Summary

You moved from a plain-language model to `resume_features` in the source and identified one verification boundary.

## Knowledge checks

1. What input does this stage receive?
2. What does `resume_features` change, return, or measure?
3. What limitation would you report before using the result outside this sample?

## References

- [Package README](../../../README.md)
- Source project files listed in module.json (relative to the Data Science & Analytics source tree).
