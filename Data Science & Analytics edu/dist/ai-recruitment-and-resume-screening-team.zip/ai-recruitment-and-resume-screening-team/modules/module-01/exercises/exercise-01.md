# Exercise: App and Main

**Exercise ID:** `exercise-01`
**Objective:** Trace `candidates` in `app.py`.
**Difficulty:** Intermediate
**Estimated time:** 45 minutes

## Problem
Explain the source behavior in this module and show how one representative input reaches the output.

## Requirements
- Cite the selected source focus and a related caller/test.
- Record inputs, transformations, output, and one boundary case.
- Separate source evidence from README claims and proposed features.

## Constraints
Use synthetic or public permitted data only. Do not claim code ran unless you actually ran it.

## Expected behavior and acceptance criteria
- Explanation matches cited source.
- One normal path and one failure/edge case are described.
- Limitations and human-review needs are stated where relevant.

## Hints
Read the function signature first, then search callers and tests.
